const search = (prefix, botName, ownerName) => {
	return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 BOT INFO 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *Creador* : ${ownerName}
   ┠≽ *Version* : 4
   ╿
┯┷ *〈 COMANDOS 〉*
╽
┠≽ *${prefix}info* (error)
┃ *Desc* : Muestra Detalles Del Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Muestra Usuarios Bloqueados
┠──────────────╼
┠≽ *${prefix}chatlist* (error)
┃ *Desc* : Muestra Todos Los Usuarios Del Chat
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Muestra Velocidad De Conexion Del Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar Bug Al Creador Del Bot
╿
┷┯ *〈 SEARCH 〉*
   ╽
   ┠≽ *${prefix}wait
   ┃ *Desc* : Enviar Nombre Anime Y Escena Corta
   ┠──────────────╼
   ┠≽ *${prefix}ytsearch <query>
   ┃ *Desc* : Buscar Video De Youtube
   ┠──────────────╼
   ┠≽ *${prefix}trendtwit
   ┃ *Desc* : Buscar Videos De Twitter En Tendencia
   ╿ *${ownerName}*,
   ╰╼≽ *Developer © ${botName}`
}
exports.search = search
