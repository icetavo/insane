const information = (prefix, botName, ownerName) => {
        return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 BOT INFO 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *Creador* : ${ownerName}
   ┠≽ *Version* : 4
   ╿
┯┷ *〈 COMANDOS 〉*
╽
┠≽ *${prefix}info* (error)
┃ *Desc* : Muestra Detalles Del Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Muestra Usuarios Bloqueados
┠──────────────╼
┠≽ *${prefix}chatlist* (error)
┃ *Desc* : Muestra Todos Los Usuarios Del Chat
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Muestra Velocidad De Conexion Del Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar Bug Al Creador Del Bot
╿
┷┯ *〈 INFORMATION 〉*
   ╽
   ┠≽ *${prefix}bahasa*
   ┃ *Desc* : Envia Codigos De Idioma
   ┠──────────────╼
   ┠≽ *${prefix}kodenegara*
   ┃ *Desc* : Envia Codigos De Paises (TODOS)
   ┠──────────────╼
   ┠≽ *${prefix}kbbi* <pregunta>
   ┃ *Desc* : Preguntando KBBI
   ┠──────────────╼
   ┠≽ *${prefix}fakta*
   ┃ *Desc* : Envia Un Hecho Aleatorio
   ┠──────────────╼
   ┠≽ *${prefix}infocuaca* <area>
   ┃ *Desc* : Envia Información Meteorológica
   ┠──────────────╼
   ┠≽ *${prefix}infogempa*
   ┃ *Desc* : Envia De Información Sobre Terremotos
   ┠──────────────╼
   ┠≽ *${prefix}covidcountry* <country>
   ┃ *Desc* : Envia Informacion Del Covid-19
   ╿ *${ownerName}*,
   ╰╼≽ *Developer © ${botName}`
}
exports.information = information
