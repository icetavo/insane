const meme = (prefix, botName, ownerName) => {
	return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 BOT INFO 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *Creador* : ${ownerName}
   ┠≽ *Version* : 4
   ╿
┯┷ *〈 COMANDOS 〉*
╽
┠≽ *${prefix}info* (error)
┃ *Desc* : Muestra Detalles Del Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Muestra Usuarios Bloqueados
┠──────────────╼
┠≽ *${prefix}chatlist* (error)
┃ *Desc* : Muestra Todos Los Usuarios Del Chat
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Muestra Velocidad De Conexion Del Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar Bug Al Creador Del Bot
╿
┷┯ *〈 MEME 〉*
   ╽
   ┠≽ *${prefix}meme*
   ┃ *Desc* : Envia Meme Random [eng]
   ┠≽ *${prefix}memeindo*
   ┃ *Desc* : Envia Meme Random [indo]
   ╿ *${ownerName}*,
   ╰╼≽ *Developer © ${botName}`
}
exports.meme = meme
