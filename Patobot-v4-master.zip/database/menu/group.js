const group = (prefix, botName, ownerName) => {
        return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 BOT INFO 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *Creador* : ${ownerName}
   ┠≽ *Version* : 4
   ╿
┯┷ *〈 COMANDOS 〉*
╽
┠≽ *${prefix}info* (error)
┃ *Desc* : Muestra Detalles Del Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Muestra Usuarios Bloqueados
┠──────────────╼
┠≽ *${prefix}chatlist* (error)
┃ *Desc* : Muestra Todos Los Usuarios Del Chat
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Muestra Velocidad De Conexion Del Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar Bug Al Creador Del Bot
╿
┷┯ *〈 GROUP 〉*
   ╽
   ┠≽ *${prefix}opengc*
   ┃ *Desc* : Abrir El Grupo
   ┠──────────────╼
   ┠≽ *${prefix}closegc*
   ┃ *Desc* : Cerrar El Grupo
   ┠──────────────╼
   ┠≽ *${prefix}promote* <@tag>
   ┃ *Desc* : Dar Administrador Ah Un Miembro Del Grupo
   ┠──────────────╼
   ┠≽ *${prefix}demote* <@tag>
   ┃ *Desc* : Remover Administrador Ah Un Miembro Del Grupo
   ┠──────────────╼
   ┠≽ *${prefix}tagall*
   ┃ *Desc* : Mencionar Ah Todos Los Miembros
   ┠──────────────╼
   ┠≽ *${prefix}tagall2*
   ┃ *Desc* : Mencionar Ah Todos Los Miembros
   ┠──────────────╼
   ┠≽ *${prefix}tagall3*
   ┃ *Desc* : Mencionar Ah Todos Los Miembros
   ┠──────────────╼
   ┠≽ *${prefix}tagall4*
   ┃ *Desc* : Mencionar Ah Todos Los Miembros
   ┠──────────────╼
   ┠≽ *${prefix}tagall5*
   ┃ *Desc* : Mencionar Ah Todos Los Miembros
   ┠──────────────╼
   ┠≽ *${prefix}add* <12542123926>
   ┃ *Desc* : Agregar Nuevo Miembro
   ┠──────────────╼
   ┠≽ *${prefix}kick* <@tag>
   ┃ *Desc* : Expulsar Miembro Del Grupo
   ┠──────────────╼
   ┠≽ *${prefix}listadmins*
   ┃ *Desc* : Lista De Los Admins Del Grupo
   ┠──────────────╼
   ┠≽ *${prefix}linkgroup*
   ┃ *Desc* : Envia Link Del Grupo
   ┠──────────────╼
   ┠≽ *${prefix}leave*
   ┃ *Desc* : Sacar Al Bot Del Grupo
   ┠──────────────╼
   ┠≽ *${prefix}welcome* <1/0>
   ┃ *Desc* : Activar / Desactivar Bienvenida Cuando Alguien Entra
   ┠──────────────╼
   ┠≽ *${prefix}nsfw* <1/0>
   ┃ *Desc* : Activar / Desactivar El Nsfw
   ┠──────────────╼
   ┠≽ *${prefix}delete*
   ┃ *Desc* : Eliminar Mensaje Del Bot
   ┠──────────────╼
   ┠≽ *${prefix}simih* <1/0>
   ┃ *Desc* : Activar / Desactivar Ah Simi
   ┠──────────────╼
   ┠≽ *${prefix}tagme*
   ┃ *Desc* : Mencionarte
   ┠──────────────╼
   ┠≽ *${prefix}ownergroup*
   ┃ *Desc* :  Muestra Al Creador Del Grupo
   ╿ *${ownerName}*,
   ╰╼≽ *Developer © ${botName}`
}
exports.group = group
