const music = (prefix, botName, ownerName) => {
        return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 BOT INFO 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *Creador* : ${ownerName}
   ┠≽ *Version* : 4
   ╿
┯┷ *〈 COMANDOS 〉*
╽
┠≽ *${prefix}info* (error)
┃ *Desc* : Muestra Detalles Del Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Muestra Usuarios Bloqueados
┠──────────────╼
┠≽ *${prefix}chatlist* (error)
┃ *Desc* : Muestra Todos Los Usuarios Del Chat
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Muestra Velocidad De Conexion Del Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar Bug Al Creador Del Bot
╿
┷┯ *〈 MUSIC 〉*
   ╽
   ┠≽ *${prefix}play* <music_name>
   ┃ *Desc* : Reproducir Audio De Musica
   ┠──────────────╼
   ┠≽ *${prefix}joox* <music_name>
   ┃ *Desc* : Reproducir Musica De Joox
   ┠──────────────╼
   ┠≽ *${prefix}lirik* <music_name>
   ┃ *Desc* : Buscar Letra De Una Cancion
   ┠──────────────╼
   ┠≽ *${prefix}chord* <music_name>
   ┃ *Desc* : Buscar Acorde De La Letra De Una Cancion
   ╿ *${ownerName}*,
   ╰╼≽ *Developer © ${botName}`
}
exports.music = music
