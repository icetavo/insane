const education = (prefix, botName, ownerName) => {
	return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 BOT INFO 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *Creador* : ${ownerName}
   ┠≽ *Version* : 4
   ╿
┯┷ *〈 ABOUT 〉*
╽
┠≽ *${prefix}info* (error)
┃ *Desc* : Muestra Detalles Del Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Muestra Usuarios Bloqueados
┠──────────────╼
┠≽ *${prefix}chatlist* (error)
┃ *Desc* : Muestra Todos Los Usuarios Del Chat
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Muestra Velocidad De Conexion Del Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar Bug Al Creador Del Bot
╿
┷┯ *〈 EDUCATION 〉*
   ╽
   ┠≽ *${prefix}wiki* <query>
   ┃ *Desc* : Buscar En Wikipedia [indo]
   ┠──────────────╼
   ┠≽ *${prefix}wikien* <query>
   ┃ *Desc* : Buscar En Wikipedia [ingles]
   ┠──────────────╼
   ┠≽ *${prefix}nulis* <texto>
   ┃ *Desc* : Escribir Un Texto En Un Libro
   ┠──────────────╼
   ┠≽ *${prefix}quotes*
   ┃ *Desc* : Envia Quotes Al Azar
   ┠──────────────╼
   ┠≽ *${prefix}quotes2*
   ┃ *Desc* : Envia Quotes Al Azar2
   ┠──────────────╼
   ┠≽ *${prefix}tafsirmimpi* <Suenos>
   ┃ *Desc* : Envia Una Interpretacion De Los Suenos
   ┠──────────────╼
   ┠≽ *${prefix}translate* <language_code>|<text>
   ┃ *Desc* : Traduce Cualquier Idioma
   ┠──────────────╼
   ┠≽ *${prefix}artinama* <nombre>
   ┃ *Desc* : Interpreta Nombres
   ╿ *${ownerName}*,
   ╰╼≽ *Developer © ${botName}`
}
exports.education = education
